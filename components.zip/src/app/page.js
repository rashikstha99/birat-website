import UnderConstruction from "@/common/UnderConstruction";

export default function Home() {
  return (
    <>
      <UnderConstruction/>
    </>
  );
}
